<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "select * from `01_01_01_modelos` where `01_01_01_cod` = $cod";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "select * from `01_01_01_modelos` where `01_01_01_cod` = $cod";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
                $_SESSION['modelo_cod'] = $u['01_01_cod'];
                $_SESSION['modelo_descricao'] = $u['01_01_descricao'];
                $_SESSION['modelo_consumo'] = $u['01_01_consumo'];
               
                    
            endforeach;

            echo json_encode($resposta);

        };

        echo  $query;




    }



?>