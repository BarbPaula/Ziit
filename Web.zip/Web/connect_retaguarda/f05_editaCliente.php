<?php

include "banco.php";

$cod = $_POST["cod"];
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$UF = $_POST["uf"];


// Insere Usuário
 // `f05_editaCliente`(cod int, nome varchar(250), email varchar(200), UF int)

$query = "call `f05_editaCliente`($cod, '$nome', '$email', $UF);";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo json_encode($resposta);


?>