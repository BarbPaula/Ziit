<?php

include "banco.php";




$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST['senha'];
$notificacao = $_POST['notificacao'];
$uf = "3";


// Insere Usuário
// `f04_salvaCliente`(nome varchar(250), email varchar(200), senha varchar(100), notificacao int, uf int)
$query = "call `f04_salvaCliente`('".$nome."','".$email."', '".$senha."', ".$notificacao.", ".$uf.")";

$teste= conecta();

$busca = mysqli_query($teste, $query);


if(mysqli_num_rows($busca)>0){

    foreach ($busca as $u):

        $resposta = $u;
            
    endforeach;

};

echo json_encode($resposta["codigo"]);
    
 

?>