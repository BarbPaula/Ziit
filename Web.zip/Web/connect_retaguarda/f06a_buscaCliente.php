<?php

include "banco.php";

$email = $_POST["email"];



// Insere Usuário
$query = "call `f06a_buscaCliente`('$email')";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

        
    foreach ($busca as $u):

       $resposta = $u;
            
    endforeach;

};


echo json_encode($resposta);

?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "call `f06_buscaCliente`($cod)";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
                $_SESSION['cliente_cod'] = $u['00_cod'];
                $_SESSION['cliente_nome'] = $u['00_nome'];
                $_SESSION['Cliente_email'] = $u['00_email'];
                $_SESSION['Cliente_uf'] = $u['00_01_UF'];
                $_SESSION['Cliente_Cadastro'] = $u['00_dtCadastro'];
                $_SESSION['Cliente_acessos'] = $u['numero'];
                    
            endforeach;

            echo json_encode($resposta);

        };

        echo  $query;


    }



?>

