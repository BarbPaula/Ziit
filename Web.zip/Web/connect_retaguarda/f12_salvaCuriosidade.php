<?php 




include "banco.php";

$cod = $_POST["cod"];

if ($_GET["id"] <> null){

    $cod = $_GET["id"];
}

$conteudo = $_POST["conteudo"];
$link = $_POST["link"];
$energia = $_POST["energia"];
$dtPubli = $_POST["dataPubli"];
$titulo = $_POST["titulo"];



// Insere Usuário
$query = "call `f12_salvaCuriosidade`(".$cod.", '".addslashes($conteudo)."','".$link."', '".$dtPubli."',".$energia.", '".$titulo."');";

$teste= conecta();

if (mysqli_connect_error($teste)){

    $popup = "Não foi possível carregar a página.";
    
    echo "<script>alert('".$popup.  "');</script>";
    echo  '<script language= "JavaScript">
            location.href="../01 - FreshUI Template (PHP)/02a - curiosidades.php?"
            </script>';
        
} else{

    $busca = mysqli_query($teste, $query);

    $resposta['resposta'] ="1";

    if(mysqli_num_rows($busca)=="1"){

        foreach ($busca as $u):

            $resposta['resposta'] = $u['login'];
                
        endforeach;

    };

    echo  '<script language= "JavaScript">
    location.href="../01 - FreshUI Template (PHP)/02a - curiosidades.php?"
    </script>';

    

}



?>