<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f21_buscaCertificado`($cod)";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "call `f21_buscaCertificado`($cod)";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
                $_SESSION['certificado_cod'] = $u['03_03_cod'];
                $_SESSION['certificado_nome'] = $u['00_nome'];
                $_SESSION['certificado_empreendimento'] = $u['03_03_descricao'];
                $_SESSION['certificado_certificado'] = $u['03_03_chave'];
                $_SESSION['certificado_fonte'] = $u['06_cod'];
                $_SESSION['certificado_ano'] = $u['03_03_ano'];

                    
            endforeach;

            echo json_encode($resposta);

        };

        echo  $query;




    }



?>