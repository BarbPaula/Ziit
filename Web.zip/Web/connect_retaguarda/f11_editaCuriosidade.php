<?php

include "banco.php";

$cod = $_POST["cod"];

if ($_GET['id'] <> null) { $cod = $_GET['id']; };



$conteudo = $_POST["conteudo"];
$link = $_POST["link"];
$energia = $_POST["energia"];
$dtPubli = $_POST["dataPubli"];
$titulo = $_POST["titulo"];

if ($_GET['id'] <> null) { $UF= "0"; };

$ddd = $_POST["ddd"];
$telefone = $_POST["telefone"];



// Insere Usuário
$query = "call `f11_editaCuriosidade`(".$cod.", '".addslashes($conteudo)."','".$link."', '".$dtPubli."',".$energia.", '".$titulo."');";
$teste= conecta();


if (mysqli_connect_error($teste)){


    $popup = "Não foi possível carregar a página.";
    
    echo "<script>alert('".$popup.  "');</script>";
    echo  '<script language= "JavaScript">
            location.href="../01 - FreshUI Template (PHP)/03-curiosidades.php?"
            </script>';
        
} else {

    $busca = mysqli_query($teste, $query);

  

    if(mysqli_num_rows($busca)=="1"){

        foreach ($busca as $u):

            $resposta['resposta'] = $u['login'];
                
        endforeach;

    };

        

        
        echo  '<script language= "JavaScript">
                   location.href="../01 - FreshUI Template (PHP)/03-curiosidades.php?"
                    </script>';

        



};

echo $query;




?>