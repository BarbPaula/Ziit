<?php

include "banco.php";

$cod = $_POST["cod"];
$dtIni = $_POST["dtIni"];
$dtFim = $_POST["dtFim"];
$gratuito = $_POST["gratuito"];




// Insere Usuário
$query = "call `f23_salvaAssinatura`(".$cod.", '".$dtIni."','".$dtFim."',".$gratuito.") as login;";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo json_encode($resposta);


?>