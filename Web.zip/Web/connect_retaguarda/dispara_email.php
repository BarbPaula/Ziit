<?php

    include "banco.php";

    $email = addslashes($_POST['i_email']);
    $mensagem = addslashes($_POST['i_mensagem']);
    $popup = "";

    // Altera a senha no banco
    $query = "select `f03_alteraSenha`('".$email."');";

    $teste= conecta();

    $busca = mysqli_query($teste, $query);

    // Dispara o email
     $to = $email;
     $subject = "Contato do site - ".$assunto;
     $body = "A Sua nova senha é 000000";
     $header = "From:barbpaula@barbara.marciomkt.com.br"."\r\n".
                    "Reply-To:".$email."\r\n".
                    "X=Mailer:PHP/".phpversion();

    if (mail($to,$subject,$body,$header)){

        $popup = "Email enviado com sucesso!";

    }else{

        $popup= "Email não pode ser enviado com sucesso!";
  
    }

    echo $popup;

?>