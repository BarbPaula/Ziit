<?php

include "banco.php";

$cod = $_POST["cod"];
$descricao = $_POST["descricao"];
$frequencia = $_POST["frequencia"];




// Insere Usuário
// `f30_salvaModeloCelular`(codUsuario int,descricao varchar(400), freq float, validar int)


$query = "call `f30_salvaModeloCelular`(".$cod.", '".$descricao."',".$frequencia.",1)";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta = $u;
            
    endforeach;

};

    echo json_encode($resposta);


?>