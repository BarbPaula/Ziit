<?php

include "banco.php";

$cod = $_POST["cod"];





// Insere Usuário
$query = "call `f11_buscaAdmins`()";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>