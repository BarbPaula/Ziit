<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f13_buscaCuriosidade`($cod)";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "call `f13_buscaCuriosidade`($cod)";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
            
                $_SESSION['conteudo_name'] = $u['00_nome'];
                $_SESSION['conteudo_titulo'] = $u['03_01_titulo'];
                $_SESSION['conteudo_fonte'] = $u['06_energia'];
                $_SESSION['conteudo_link'] = $u['03_01_link'];
                $_SESSION['conteudo_data'] = $u['03_01_data'];
                $_SESSION['conteudo_conteudo'] = $u['03_01_conteudo'];
                $conteudo = $u['03_01_conteudo'];
                    
            endforeach;

            echo json_encode($resposta);

        };

        echo  $query;




    }



?>