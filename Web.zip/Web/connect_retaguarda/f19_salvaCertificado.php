<?php

include "banco.php";

$cod = $_POST["cod"];
$energia = $_POST["energia"];
$ano = $_POST["ano"];
$descricao = $_POST["empreendimento"];
$certificado = $_POST["certificado"];


$cod = $_POST["cod"];

if ($_GET["id"] <> null){

    $cod = $_GET["id"];
}



// Insere Usuário
$query = "call `f19_salvaCertificado`(".$cod.", ".$energia.",'".$ano."','".$descricao."', '".$certificado."')";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};



echo  '<script language= "JavaScript">
        location.href="../01 - FreshUI Template (PHP)/02-Certificados.php?"
        </script>';


?>