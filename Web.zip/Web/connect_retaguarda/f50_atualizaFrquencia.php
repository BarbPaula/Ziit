<?php

include "banco.php";

$cod = $_POST["cod"];
$frequencia = $_POST['frequencia']


// Insere Usuário
// `f04_salvaCliente`(nome varchar(250), email varchar(200), senha varchar(100), notificacao int, uf int)
$query = "update `01_01_celulares` set `01_01_cargas` = $carga where `01_01_cod` = $cod";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo json_encode($resposta);


?>