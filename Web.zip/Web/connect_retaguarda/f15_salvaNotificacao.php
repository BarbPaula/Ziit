<?php 




include "banco.php";

$cod = $_POST["cod"];

if ($_GET["id"] <> null){

    $cod = $_GET["id"];
}

$conteudo = $_POST["conteudo"];
$dtPubli = $_POST["data"];
$titulo = $_POST["titulo"];
$usuario = $_POST["usuarios"];
$so = $_POST["so"];



// Insere Usuário
$query = "call `f15_salvaNotificacao`(".$cod.", '".addslashes($conteudo)."',$usuario, '".$dtPubli."',".$so.", '".$titulo."');";

$teste= conecta();

if (mysqli_connect_error($teste)){

    $popup = "Não foi possível carregar a página.";
    
    echo "<script>alert('".$popup.  "');</script>";
    echo  '<script language= "JavaScript">
            location.href="../01 - FreshUI Template (PHP)/04-notificacoes.php?"
            </script>';
        
} else{

    $busca = mysqli_query($teste, $query);

    $resposta['resposta'] ="1";

    if(mysqli_num_rows($busca)=="1"){

        foreach ($busca as $u):

            $resposta['resposta'] = $u['login'];
                
        endforeach;

    };


    echo  '<script language= "JavaScript">
    location.href="../01 - FreshUI Template (PHP)/04-notificacoes.php?"
    </script>';

    

}



?>