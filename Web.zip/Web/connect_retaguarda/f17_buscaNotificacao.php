<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f17_buscaNotificacao`($cod)";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "call `f17_buscaNotificacao`($cod)";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
                $_SESSION['notificacao_cod'] = $u['03_02_cod'];
                $_SESSION['notificacao_name'] = $u['00_nome'];
                $_SESSION['notificacao_titulo'] = $u['03_02_titulo'];
                $_SESSION['notificacao_sistema'] = $u['03_02_sistemaOperacional'];
                $_SESSION['notificacao_data'] = $u['03_02_data'];
                $_SESSION['notificacao_conteudo'] = $u['03_02_conteudo'];
                $_SESSION['notificacao_usuarios'] = $u['03_02_usuarios_ativos'];

                    
            endforeach;

            echo json_encode($resposta);

        };

        echo  $query;




    }



?>