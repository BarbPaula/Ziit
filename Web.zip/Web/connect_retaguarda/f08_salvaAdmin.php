<?php

include "banco.php";


$ddd = $_POST["ddd"];
$telefone = $_POST["telefone"];
$nome = $_POST["nome"];
$email = $_POST["email"];
$pass = $_POST["senha"];


// Insere Usuário
$query = "select `f01_insereUsuario`('".$email."','".$nome."', '".$pass."') as login;";

$teste= conecta();

if (mysqli_connect_error($teste)){

    $popup = "Não foi possível carregar a página.";
    
    echo "<script>alert('".$popup.  "');</script>";
    echo  '<script language= "JavaScript">
            location.href="../01 - FreshUI Template (PHP)/06a-admins.php?"
            </script>';
        
} else{

    $busca = mysqli_query($teste, $query);

    $resposta['resposta'] ="1";

    if(mysqli_num_rows($busca)=="1"){

    

        foreach ($busca as $u):

            $cod = $u['login'];
                
        endforeach;

    };




    // Insere Usuário
    $query = "call `f08_salvaAdmin`(".$cod.", '".$ddd."','".$telefone."');";

    $teste= conecta();

    if (mysqli_connect_error($teste)){

        $popup = "Não foi possível carregar a página.";

        echo "<script>alert('".$popup.  "');</script>";
        echo  '<script language= "JavaScript">
        location.href="../01 - FreshUI Template (PHP)/06a-admins.php?"
        </script>';
    
    } else {

        $busca = mysqli_query($teste, $query);

        $resposta['resposta'] ="1";

        if(mysqli_num_rows($busca)<>"0"){

            foreach ($busca as $u):

                $resposta['resposta'] = $u['login'];
                    
            endforeach;

        };

        echo  '<script language= "JavaScript">
        location.href="../01 - FreshUI Template (PHP)/06a-admins.php?"
        </script>';



    };


};



    


?>