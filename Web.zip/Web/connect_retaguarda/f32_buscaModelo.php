//

<?

include "banco.php";

$email = $_POST["email"];


// Insere Usuário
$query = "select * from `01_01_01_modelos`;";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>