<?php

include "banco.php";

$cod = $_POST["cod"];

if ($_GET['id'] <> null) { $cod = $_GET['id']; };



$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$UF = $_POST["uf"];

if ($_GET['id'] <> null) { $UF= "0"; };

$ddd = $_POST["ddd"];
$telefone = $_POST["telefone"];



// Insere Usuário
$query = "call `f09_editarAdmin`(".$cod.", '".$nome."','".$email."', '".$senha."', ".$UF.", '".$ddd."', '".$telefone."');";
$teste= conecta();


if (mysqli_connect_error($teste)){


    $popup = "Não foi possível carregar a página.";
    
    echo "<script>alert('".$popup.  "');</script>";
    echo  '<script language= "JavaScript">
            location.href="../01 - FreshUI Template (PHP)/06-admins.php?"
            </script>';
        
} else {

    $busca = mysqli_query($teste, $query);

  

    if(mysqli_num_rows($busca)=="1"){

        foreach ($busca as $u):

            $resposta['resposta'] = $u['login'];
                
        endforeach;

    };

        

        
        echo  '<script language= "JavaScript">
                   location.href="../01 - FreshUI Template (PHP)/06-admins.php?"
                    </script>';

        



};

echo $query;




?>