<?php

include "banco.php";

$descricao = $_POST["nome"];
$consumo = $_POST["carga"];
$validar= "1";




// Insere Usuário
$query = "insert into `01_01_01_modelos` (`01_01_descricao`, `01_01_consumo`, `01_01_01_validar`) values ( '".$descricao."',".$consumo.",".$validar.")";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo $query;


?>