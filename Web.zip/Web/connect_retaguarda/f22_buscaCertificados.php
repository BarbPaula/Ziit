<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f22_buscaCertificados`();";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};
    


?>