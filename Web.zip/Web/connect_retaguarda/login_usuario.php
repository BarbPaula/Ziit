<?php

include "banco.php";

$email = $_POST["email"];
$pass = $_POST["senha"];

// Insere Usuário
// `f02_loginUsuario`(email varchar(200), pass varchar (100), perfil int)


$query = " select`f02_loginUsuario`('$email', '$pass', 1) as login";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)=="1"){

          
    foreach ($busca as $u):

        $resposta = $u;
            
    endforeach;

    
};

echo json_encode($resposta['login']);

?>

<?php

    function Login($usuario, $senha){

        // Faz Login
        $query = "select `f02_loginUsuario`('".$usuario."', '".$senha."') as login;";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)=="1"){

                
            foreach ($busca as $u):

                $resposta = $u['login'];
                $_SESSION["00_cod"] = $u['login'];
                    
            endforeach;
        };


        // Busca Dados
        $query = "select * from `00_usuario` where `00_email` like '".$usuario."'";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)=="1"){

            foreach ($busca as $u):

                $_SESSION["00_nome"] = $u["00_nome"];
                $_SESSION["00_cod"] = $u['00_cod'];

         
                    
            endforeach;


     
        } else{


        };




    }






?>