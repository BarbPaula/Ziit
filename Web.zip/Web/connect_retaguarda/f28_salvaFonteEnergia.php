<?php

include "banco.php";

$fonte= $_POST["fonte"];
$cod = $_POST["cod"];
$frequencia = $_POST["frequencia"];
$carga = $_POST["carga"];





// Insere Usuário
// f28_salvaFonteEnergia`(fonte int, celular int)
$query = "call `f28_salvaFonteEnergia`(".$fonte.", ".$cod.",$frequencia,$carga);";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo json_encode($resposta);


?>