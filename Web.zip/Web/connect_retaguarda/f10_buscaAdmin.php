<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f10_buscaAdmin`('.$cod.')";

$teste= conecta();

$busca = mysqli_query($teste, $query);

if(mysqli_num_rows($busca)<>"0"){

          
    foreach ($busca as $u):

        $resposta[] = $u;
            
    endforeach;

    echo json_encode($resposta);

};



?>

<?

    function pesquisa($cod){
        
        // Insere Usuário
        $query = "call `f10_buscaAdmin`('.$cod.')";

        $teste= conecta();

        $busca = mysqli_query($teste, $query);

        if(mysqli_num_rows($busca)<>"0"){

                
            foreach ($busca as $u):

                $resposta[] = $u;
                $_SESSION['admin_name'] = $u['00_nome'];
                $_SESSION['admin_email'] = $u['00_email'];
                $_SESSION['admin_ddd'] = $u['03_ddd'];
                $_SESSION['admin_numero'] = $u['03_numero'];
                $_SESSION['admin_senha'] = $u['00_password'];
                    
            endforeach;

            echo json_encode($resposta);

        };




    }



?>