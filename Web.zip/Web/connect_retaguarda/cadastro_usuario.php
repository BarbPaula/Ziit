<?php

include "banco.php";

$nome = $_POST["name"];
$email = $_POST["email"];
$pass = $_POST["mobile"];

// Insere Usuário
$query = "select `f01_insereUsuario`('".$email."','".$nome."', '".$pass."','') as login;";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

   

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

    };

    echo json_encode($resposta);


?>