<?php

include "banco.php";

$cod = $_POST["cod"];



// Insere Usuário
$query = "call `f29_buscaFonteEnergia`(".$cod.");";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta[] = $u[];
            
    endforeach;

};

  //  echo json_encode($resposta);


?>