<?php

include "banco.php";

$cod = $_POST["cod"];
$notificacao = $_POST["notificacao"];


// Insere Usuário
 // `f05_editaCliente`(cod int, nome varchar(250), email varchar(200), UF int)

$query = "call f40_salvaVisualizacaoNotificacao($cod, $notificacao);";

$teste= conecta();

$busca = mysqli_query($teste, $query);

$resposta['resposta'] ="1";

if(mysqli_num_rows($busca)=="1"){

    foreach ($busca as $u):

        $resposta['resposta'] = $u['login'];
            
    endforeach;

};

    echo json_encode($resposta);


?>