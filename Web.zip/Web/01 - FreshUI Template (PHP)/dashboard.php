<?php 
    error_reporting(0);
    session_start(); 
    include 'inc/config.php'; // Configuration php file ?>
    
<?php include 'inc/top.php';    // Meta data and header   ?>

<div style="display:none;">
    <?php include '../connect_retaguarda/f14_buscaCuriosidades.php';?>
</div>

<div style="display=none;">
    <?php 

        $b=1;
        $e=1;

        $_SESSION['00_nome'] = "Bárbara de Paula" ;
        $_SESSION['00_cod'] = "118" ;
    
        if ( isset($_SESSION['00_nome']) == false ){
            


            $_SESSION['00_nome'] = "Bárbara" ;
            
        };

        
        

    ?>

</div>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Dashboard Header -->
    <div class="block-header">
        <div class="row remove-margin">
            <!-- Title -->
            <div class="col-md-4">
                <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
                <a href="" class="header-title-link">
                    <h1>Dashboard<br><small>Bem-Vindo <?php echo $_SESSION['00_nome'];?></small></h1>
                </a>
            </div>
            <!-- END Title -->

             

            <!-- Statistics -->
            <div class="col-md-8">
                <!-- Outer Grid -->
                <div class="row">
                    <div class="col-sm-6">
                        <!-- Inner Grid 1 -->
                        <div class="row">
                            <div class="col-xs-6">
                                <a href="page_comp_charts.php" class="header-link">
                                    <h1 class="animation-pullDown">
                                        <strong>75</strong><br><small>Acessos nos últimos 7 dias</small>
                                    </h1>
                                </a>
                            </div>
                            <div class="col-xs-6">
                                <a href="page_comp_charts.php" class="header-link">
                                    <h1 class="animation-pullDown">
                                        <strong>20</strong><br><small>Acessos às Curiosidades</small>
                                    </h1>
                                </a>
                            </div>
                        </div>
                        <!-- END Inner Grid 1 -->
                    </div>
                    <div class="col-sm-6">
                        <!-- Inner Grid 2 -->
                        <div class="row">
                            <div class="col-xs-6">
                                <a href="page_special_timeline.php" class="header-link">
                                    <h1 class="animation-pullDown">
                                        <strong>7</strong><br><small>Cadastrados</small>
                                    </h1>
                                </a>
                            </div>
                            <div class="col-xs-6">
                                <a href="page_special_message_center.php" class="header-link">
                                    <h1 class="animation-pullDown">
                                        <strong>5</strong><br><small>Anônimos</small>
                                    </h1>
                                </a>
                            </div>
                        </div>
                        <!-- END Inner Grid 2 -->
                    </div>
                </div>
                <!-- END Outer Grid  -->
            </div>
            <!-- END Statistics -->
        </div>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-coffee"></i></li>
        <li><a href="">Dashboard</a></li>
    </ul>
    <!-- END Dashboard Header -->

    <!-- Easy Pie Charts Block -->
    <div class="block">
        <!-- Easy Pie Charts Title -->
        <div class="block-title">
            
            <h2><i class="fa fa-tasks"></i> Consumo (por Fonte)</h2>
        </div>
        <!-- END Easy Pie Charts Title -->

        <!-- Easy Pie Charts Content -->
        <div class="row text-center">
            <div class="col-sm-3">
                <!-- Just add the class .pie-chart as well as the values you would like at data-percent and data-size (in px), it is initialized in main.js -->
                <div class="pie-chart block-section" data-percent="25" data-size="150">
                    <span>25%</span>
                </div>
                <span>Eólica</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="50" data-size="150">
                    <span>50%</span>
                </div>
                <span>Hídrica</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="75" data-size="150">
                    <span>75%</span>
                </div>
                <span>Solar</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="100" data-size="150">
                    <span>100%</span>
                </div>
                <span>Biomassa</span>
            </div>
        </div>
        <!-- END Easy Pie Charts Content -->
    </div>
    <!-- END Easy Pie Charts Block -->

    <!-- Dashboard Content -->
    <div class="row gutter30">
        <div class="col-md-6">
            
            <!-- Recent Updates Block -->
            <div class="block full">
                <!-- Recent Updates Title -->
                <div class="block-title">
                    
                    <h2><i class="fa fa-graduation-cap"></i> Curiosidades</h2>
                </div>
                <!-- END Recent Updates Title -->

                <!-- Updates -->
                <div class="timeline-con">
                    <ul class="timeline remove-margin">
                        <?php   foreach($resposta as $resposta): ?>

                            <? $c = $b%2;?>

                            <li class="alt-color <?  echo  $c==0?"text-right":""; $b=$b+1;?>">
                                <div class="timeline-item">
                                    <h4 class="timeline-title"><small class="timeline-meta"><?php echo $resposta['03_01_data'];  ?> - <?php echo $resposta['00_nome'];  ?></small><i class="fa fa-plus"></i> <?php echo  addslashes((substr ( $resposta['03_01_titulo'] , 0 , 100 ) ));  ?></h4>
                                    <div class="timeline-content">
                                        <p class="clearfix">
                                            <?echo  $resposta['03_01_conteudo'];?>
                                        </p>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                        
                    </ul>
                </div>
                <!-- END Updates -->
            </div>
            <!-- END Recent Updates Block -->
        </div>

        <?

                // Insere Usuário
                $query = "call `f18_buscaNotificacoes`();";

                $teste= conecta();

                $busca = mysqli_query($teste, $query);



                if(mysqli_num_rows($busca)<>"0"){

                        
                    foreach ($busca as $u):

                        $resposta3[] = $u;
                            
                    endforeach;

                    

                };
        
        
        
        ?>


        <div class="col-md-6">
            
            <!-- Recent Updates Block -->
            <div class="block full">
                <!-- Recent Updates Title -->
                <div class="block-title">
                    <h2><i class="fa fa-bell-o"></i> Notificações</h2>
                </div>
                <!-- END Recent Updates Title -->
                
                <!-- Updates -->
                <div class="timeline-con">
                    <ul class="timeline remove-margin">
                    <?php foreach($resposta3 as $resposta): ?>
                        <? $d = $e%2;?>
                        <li class="alt-color <?  echo  $d==0?"text-right":""; $e=$e+1;?>">
                            <div class="timeline-item">
                                <h4 class="timeline-title"><small class="timeline-meta"><?echo  $resposta['03_02_data'];?> - <?echo  $resposta['00_nome'];?></small><i class="fa fa-plus"></i> <?echo  $resposta['03_02_titulo'];?></h4>
                                <div class="timeline-content">
                                    <p class="clearfix">
                                        <?echo  $resposta['03_02_conteudo'];?>
                                    </p>
                                    
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                        
                    </ul>
                </div>
                <!-- END Updates -->
            </div>
            <!-- END Recent Updates Block -->
        </div>
        
    </div>
    <!-- END Dashboard Content -->
</div>
<!-- END Page Content -->

<!-- Remember to include excanvas for IE8 chart support -->
<!--[if IE 8]><script src="js/helpers/excanvas.min.js"></script><![endif]-->

<?php include 'inc/footer.php'; // Footer and scripts ?>

<!-- Javascript code only for this page -->
<script>
    $(function(){
        // Set up timeline scrolling functionality
        $('.timeline-con').slimScroll({ height: 565, color: '#000000', size: '3px', touchScrollStep: 100, distance: '0' });
        $('.timeline').css('min-height', '565px');

        // Demo status updates and timeline functionality
        var statusUpdate    = $('#status-update');
        var statusUpdateVal = '';

        $('#accept-request').click(function(){ $(this).replaceWith('<span class="label label-success">Awesome, you became friends!'); });

        $('#status-update-btn').click(function(){
            statusUpdateVal = statusUpdate.val();

            if ( statusUpdateVal ) {
                $('.timeline-con').slimScroll({scrollTo: '0px'});

                $('.timeline').prepend('<li class="animation-pullDown">' +
                        '<div class="timeline-item">' +
                        '<h4 class="timeline-title"><small class="timeline-meta">just now</small><i class="fa fa-file"></i> Status</h4>' +
                        '<div class="timeline-content"><p>' + $('<div />').text(statusUpdateVal).html().substring(0, 200) + '</p><em>Demo functionality</em></div>' +
                        '</div>' +
                        '</li>');

                statusUpdate.val('').attr('placeholder', 'I hope you like it! :-)');
            }
        });

        /*
         * Flot 0.8.3 Jquery plugin is used for charts
         *
         * For more examples or getting extra plugins you can check http://www.flotcharts.org/
         * Plugins included in this template: pie, resize, stack
         */

        // Get the elements where we will attach the charts
        var chartClassic    = $('#chart-classic');

        // Random data for the charts
        var dataEarnings    = [[0, 60],[1, 100],[2, 80],[3, 84],[4, 124],[5, 90],[6, 150]];
        var dataSales       = [[0, 30],[1, 50],[2, 40],[3, 42],[4, 62],[5, 45],[6, 75]];

        /* Classic Chart */
        $.plot(chartClassic,
            [
                {
                    data: dataEarnings,
                    lines: { show: true, fill: true, fillColor: { colors: [{ opacity: 0.25 }, { opacity: 0.25 }] } },
                    points: { show: true, radius: 7 }
                },
                {
                    data: dataSales,
                    lines: { show: true, fill: true, fillColor: { colors: [{ opacity: 0.15 }, { opacity: 0.15 }] } },
                    points: { show: true, radius: 7 }
                }
            ],
            {
                colors: ['#f39c12', '#2e3030'],
                legend: { show: false },
                grid: { borderWidth: 0, hoverable: true, clickable: true },
                yaxis: { show: false },
                xaxis: { show: false }
            }
        );

        // Creating and attaching a tooltip to the classic chart
        var previousPoint = null, ttlabel = null;
        chartClassic.bind('plothover', function (event, pos, item) {

            if (item) {
                if (previousPoint !== item.dataIndex) {
                    previousPoint = item.dataIndex;

                    $('#chart-tooltip').remove();
                    var x = item.datapoint[0], y = item.datapoint[1];

                    if ( item.seriesIndex === 1 ) {
                        ttlabel = '<strong>' + y +'</strong> sales';
                    } else {
                        ttlabel = '$ <strong>' + y +'</strong>';
                    }

                    $('<div id="chart-tooltip" class="chart-tooltip">' + ttlabel + '</div>')
                        .css( { top: item.pageY - 45, left: item.pageX + 5 }).appendTo("body").show();
                }
            }
            else {
                $('#chart-tooltip').remove();
                previousPoint = null;
            }
        });
    });
</script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>