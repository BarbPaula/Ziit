<?php session_start();  include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<?php include '../connect_retaguarda/f17_buscaNotificacao.php';?>

<div style="display:none;">

    <?php

    

    if($_GET['func']=="2"){

        pesquisa($_GET['id']);
        
        $visivelSalvar = "none";
        $visivelAlterar = "flex";

    }else{

        $_SESSION['notificacao_cod'] = "";
        $_SESSION['notificacao_name'] = "";
        $_SESSION['notificacao_titulo'] = "";
        $_SESSION['notificacao_sistema'] = "";
        $_SESSION['notificacao_data'] = "";
        $_SESSION['notificacao_conteudo'] = "";
        $_SESSION['notificacao_usuarios'] = "";

        
        

        $visivelSalvar = "flex";
        $visivelAlterar = "none";

    };



    ?>
</div>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Forms General Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Notificações - Cadastro<br><small> Cadastro de notificações.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-pencil-square-o"></i></li>
        <li>Notificações</li>
        <li><a href="">Cadastro</a></li>
    </ul>
    <!-- END Forms General Header -->

    <!-- Basic Form Elements Block -->
    <div class="block">
        <!-- Basic Form Elements Title -->
        <div class="block-title">
            <h2>Notificação</h2>
        </div>
        <!-- END Form Elements Title -->

        <!-- Basic Form Elements Content -->
        <form action="<?if ($_GET['func'] == "2") {echo '../connect_retaguarda/f16_editaNotificacao.php?id='.$_GET['id'];} else {echo '../connect_retaguarda/f15_salvaNotificacao.php?id='. $_SESSION["00_cod"];};?>" method="post" enctype="multipart/form-data" class="form-horizontal">
            <h4 class="sub-header">Cadastro</h4> 
            <div class="form-group">
                <label class="col-md-2 control-label text-left">Autor:</label>
                <div class="col-md-6">
                <p class="form-control-static text-left"><?php echo $_SESSION["00_cod"]; echo " - "; echo $_SESSION['00_nome'];?> </p> <!--Adicionar nome de usuário-->
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-2 control-label" for="example-text-input">Título</label>
                <div class="col-sm-7">
                    <input type="text" id="example-text-input" name="titulo" class="form-control" placeholder="" value="<?echo  $_SESSION['notificacao_titulo'] ;?>">
                    
                </div>
            </div>

            <!-- Datetimepicker for Bootstrap, for usage examples you can check out http://eonasdan.github.io/bootstrap-datetimepicker/ -->
              
                <div class="form-group">
                <label class="control-label col-md-2" for="example-datepicker3">Data de Publicação</label>
                <div class="col-md-2">
                    <input type="text" id="dataPubli" name="data" class="form-control input-datepicker-close text-left" data-date-format="dd/mm/yy" placeholder="dd/mm/yy" value="<?echo  $_SESSION['notificacao_data'] ;?>">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-select">Sistema Operacional</label>
                <div class="col-md-2">
                    <select id="example-select" name="so" class="form-control" size="1">
                        <option value="1" <?php if($_SESSION['notificacao_sistema'] == 1){echo "selected";};?>>IOS</option>
                        <option value="2" <?php if($_SESSION['notificacao_sistema'] == 2){echo "selected";};?>>Android</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-select">Somente Usuários Ativos?</label>
                <div class="col-md-2">
                    <select id="example-select" name="usuarios" class="form-control" size="1">
                        <option value="1" <?php if($_SESSION['notificacao_usuarios'] == 1){echo "selected";};?>>Sim</option>
                        <option value="2" <?php if($_SESSION['notificacao_usuarios'] == 2){echo "selected";};?>>Não</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-textarea-input">Textarea</label>
                <div class="col-md-5">
                    <textarea id="example-textarea-input" name="conteudo" rows="4" class="form-control" placeholder="Content..">
                        <?php

                            echo $_SESSION['notificacao_conteudo'];
                        
                        ?>
                    </textarea>
                </div>
            </div>

            <div class="form-group text-right">
            
                <tr class="text-right">
                   
                    <td><button style="display: <?echo $visivelAlterar?>" type="submit" class="btn btn-warning">Alterar</button></td>
                </tr>
            </div>
            
            <div class="form-group text-right">
                <tr class="text-right">
                    <td><button style="display: <?echo $visivelSalvar?>" type="submit" class="btn btn-success">Salvar</button></td>
                    
                </tr>

            </div>
            

        </form>       
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>


<?php include 'inc/bottom.php'; // Close body and html tags ?>