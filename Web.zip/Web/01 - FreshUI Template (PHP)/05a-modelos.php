<?php session_start(); include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<?php include '../connect_retaguarda/f33_buscaModeloCelular.php';?>


<div style="display:none;">

    <?php

    if($_GET['func']=="2"){

        pesquisa($_GET['id']);
        
        $visivelSalvar = "none";
        $visivelAlterar = "flex";

    }else{

        $_SESSION['modelo_cod'] = "";
        $_SESSION['modelo_descricao'] = "";
        $_SESSION['modelo_consumo'] = "";

        $visivelSalvar = "flex";
        $visivelAlterar = "none";

    };



    ?>

</div>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Forms General Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
               Modelo de Aparelho - Cadastro<br><small> Cadastro de Modelo de Aparelho.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-pencil-square-o"></i></li>
        <li>Aparelho</li>
        <li><a href="">Cadastro</a></li>
    </ul>
    <!-- END Forms General Header -->

    <!-- Basic Form Elements Block -->
    <div class="block">
        <!-- Basic Form Elements Title -->
        <div class="block-title">
            <h2>Aparelho</h2>
        </div>
        <!-- END Form Elements Title -->

        <!-- Basic Form Elements Content -->
        <form action="<?if ($_GET['func'] == "2") {echo '../connect_retaguarda/f31_editaModelo.php?id='.$_GET['id'];} else {echo '../connect_retaguarda/f30_salvaModeloCelular.php?id='. $_SESSION["00_cod"];};?>" method="post" enctype="multipart/form-data" class="form-horizontal">
            <h4 class="sub-header">Cadastro</h4> 

            <div class="form-group">
                <label class="col-md-2 control-label text-left">Autor:</label>
                <div class="col-md-6">
                    <p class="form-control-static text-left"><?php echo $_SESSION["00_cod"]; echo " - "; echo $_SESSION['00_nome'];?> </p> <!--Adicionar nome de usuário-->
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-text-input">Modelo</label>
                <div class="col-sm-7">
                    <input type="text" id="example-text-input" name="nome" class="form-control" placeholder="" value="<?echo  $_SESSION['modelo_descricao'] ;?>" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                    
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="val_number">Total por Carga</label>
                <div class="col-md-2">
                    <div class="input-group">
                        <input type="text" id="val_number" name="carga" class="form-control" value="<?echo  $_SESSION['modelo_consumo'] ;?>" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                        
                    </div>
                </div>
            </div>
            
            
            <div class="form-group text-right">
                <tr class="text-right">
                    <td><button style="display: <?echo $visivelSalvar?>" type="submit" class="btn btn-success">Salvar</button></td>
                    
                </tr>

            </div>

        </form>       
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>


<?php include 'inc/bottom.php'; // Close body and html tags ?>