<?php  include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<div style="display: none;">
<?php include '../connect_retaguarda/f18_buscaNotificacoes.php';?>
</div>


<!-- Page content -->
<div id="page-content" class="block full">
    <!-- Datatables Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Notificações<br><small>Estas são as Notificações Cadastradas.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-th"></i></li>
        <li>Notificações</li>
        <li><a href="">Consulta</a></li>
    </ul>
    <!-- END Datatables Header -->

    <!-- Datatables Content -->
    <p>[Texto Explicativo]</p>
    
    <div class="table-responsive">
        <table id="example-datatable" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th>Título</th>
                    <th>Sistema</th>
                    <th>Somente Ativos</th>
                    <th>Autor</th>
                    <th>Data</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody>
               
                <?php foreach($resposta as $resposta): ?>
                <tr>
                    <td class="text-center"><?php echo $resposta['03_02_cod'];  ?></td>
                    <td><?php echo  (substr ( $resposta['03_02_titulo'] , 0 , 100 ) )  ?></td>
                    <td><?php echo (($resposta['03_02_sistemaOperacional']=="1")?"IOS":"Android"); ?></td>
                    <td><?php echo (($resposta['03_02_usuario_ativo']=="1")?"Sim":"Não"); ?></td>
                    <td><?php echo $resposta['00_nome'];  ?></td>
                    <td><?php echo $resposta['03_02_data'];  ?></td>
                    <td class="text-center">
                        <div class="btn-group">
                        <a href="04a - notificacoes.php?func=2&id=<?php echo $resposta['03_02_cod']; ?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- END Datatables Content -->
</div>
<!-- END Page Content -->

<?php include 'inc/footer.php'; // Footer and scripts ?>

<!-- Javascript code only for this page -->
<script>
    $(function(){
        /* Initialize Bootstrap Datatables Integration */
        webApp.datatables();

        /* Initialize Datatables */
        $('#example-datatable').dataTable({
            columnDefs: [{orderable: false, targets: [4]}],
            pageLength: 15,
            lengthMenu: [[15, 30, 50, -1], [15, 30, 50, "All"]]
        });

        /* Add placeholder attribute to the search form */
        $('.dataTables_filter input').attr('placeholder', 'Search');
    });
</script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>