

<?php include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<div style="display: none;">
<?php include '../connect_retaguarda/f22_buscaCertificados.php';?>
</div>


<!-- Page content -->
<div id="page-content" class="block full">
    <!-- Datatables Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Certificados<br><small>Estes são os Certificados Cadastrados.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-th"></i></li>
        <li>Certificados</li>
        <li><a href="">Consulta</a></li>
    </ul>
    <!-- END Datatables Header -->

    <!-- Datatables Content -->
    <p>[Texto Explicativo]</p>

    <!-- Easy Pie Charts Content -->
    <div class="row text-center">
            <div class="col-sm-3">
                <!-- Just add the class .pie-chart as well as the values you would like at data-percent and data-size (in px), it is initialized in main.js -->
                <div class="pie-chart block-section" data-percent="25" data-size="150">
                    <span>25%</span>
                </div>
                <span>Eólica</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="50" data-size="150">
                    <span>50%</span>
                </div>
                <span>Hídrica</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="75" data-size="150">
                    <span>75%</span>
                </div>
                <span>Solar</span>
            </div>
            <div class="col-sm-3">
                <div class="pie-chart block-section" data-percent="100" data-size="150">
                    <span>100%</span>
                </div>
                <span>Biomassa</span>
            </div>
        </div>
        <br>
        <br>
    <?php
                $labels['4']['class'] = "label-success";
                $labels['4']['text'] = "Biomassa";

                $labels['3']['class'] = "label-primary";
                $labels['3']['text'] = "Eólica";

                $labels['2']['class'] = "label-info";
                $labels['2']['text'] = "Hídrica";

                $labels['1']['class'] = "label-danger";
                $labels['1']['text'] = "Solar";
                ?>
    
    <div class="table-responsive">
        <table id="example-datatable" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Empreendimento</th>
                    <th class="text-center">Fonte</th>
                    <th class="text-center">Número</th>
                    <th>Ano</th>
                    <th>Cadastrado por</th>
                    <th>Data</th>
                    <th>Fonte</th>
                    <th>Consumo</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody>
               
                <?php foreach($resposta as $resposta): ?>
                <tr>
                    <td class="text-center"><?php echo $resposta['03_03_cod'];  ?></td>
                    <td class="text-center"><?php echo $resposta['03_03_descricao'];  ?></td>
                    <td><span class="label<?php echo ($labels[$resposta['06_cod']]['class']) ? " " . $labels[$resposta['06_cod']]['class'] : ""; ?>"><?php echo $resposta['06_descricao']; ?></span></td>
                    <td class="text-center"><?php echo $resposta['03_03_chave'];  ?></td>
                    <td class="text-center"><?php echo $resposta['03_03_ano'];  ?></td>
                    <td><?php echo  $resposta['00_nome']   ?></td>
                    <td><?php echo $resposta['03_03_data'];  ?></td>
                    <td><?php echo $resposta['06_descricao'];  ?></td>  
                    <td>
                        <div class="progress">
                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">20%</div>
                        </div>


                    </td>  

                    <td class="text-center">
                        <div class="btn-group">
                            <a href="02a-Certificados.php?func=2&id=<?php echo $resposta['03_03_cod']; ?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                        </div>
                    </td>
                    
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- END Datatables Content -->
</div>
<!-- END Page Content -->

<?php include 'inc/footer.php'; // Footer and scripts ?>

<!-- Javascript code only for this page -->
<script>
    $(function(){
        /* Initialize Bootstrap Datatables Integration */
        webApp.datatables();

        /* Initialize Datatables */
        $('#example-datatable').dataTable({
            columnDefs: [{orderable: false, targets: [6]}],
            pageLength: 15,
            lengthMenu: [[15, 30, 50, -1], [15, 30, 50, "All"]]
        });

        /* Add placeholder attribute to the search form */
        $('.dataTables_filter input').attr('placeholder', 'Search');
    });
</script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>