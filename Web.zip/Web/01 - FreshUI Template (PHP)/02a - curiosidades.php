<?php session_start();  include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>


<?php include '../connect_retaguarda/f13_buscaCuriosidade.php';?>


<div style="display:none;">

    <?php

    

    if($_GET['func']=="2"){

        pesquisa($_GET['id']);
        
        $visivelSalvar = "none";
        $visivelAlterar = "flex";

    }else{

        $_SESSION['conteudo_name'] = "";
        $_SESSION['conteudo_titulo'] = "";
        $_SESSION['conteudo_fonte'] = "";
        $_SESSION['conteudo_link'] = "";
        $_SESSION['conteudo_data'] = "";
        $_SESSION['conteudo_conteudo'] = "";

        
        

        $visivelSalvar = "flex";
        $visivelAlterar = "none";

    };



    ?>

</div>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Forms General Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Curiosidades - Cadastro<br><small> Cadastro de curiosidades.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-pencil-square-o"></i></li>
        <li>Curiosidades</li>
        <li><a href="">Cadastro</a></li>
    </ul>
    <!-- END Forms General Header -->

    <!-- Basic Form Elements Block -->
    <div class="block">
        <!-- Basic Form Elements Title -->
        <div class="block-title">
            <h2>Curiosidade</h2>
        </div>
        <!-- END Form Elements Title -->

        

        <!-- Basic Form Elements Content -->
        <form action="<?if ($_GET['func'] == "2") {echo '../connect_retaguarda/f11_editaCuriosidade.php?id='.$_GET['id'];} else {echo '../connect_retaguarda/f12_salvaCuriosidade.php?id='. $_SESSION["00_cod"];};?>" method="post" enctype="multipart/form-data" class="form-horizontal" >
            <h4 class="sub-header">Cadastro</h4> 

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-text-input">Título</label>
                <div class="col-sm-7">
                    <input type="text" id="titulo" name="titulo" class="form-control" placeholder="" value="<?echo  $_SESSION['conteudo_titulo'] ;?>">
                    
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-2 control-label text-left">Autor:</label>
                <div class="col-md-6">
                    <p class="form-control-static text-left"><?php echo $_SESSION["00_cod"]; echo " - "; echo $_SESSION['00_nome'];?> </p> <!--Adicionar nome de usuário-->
                </div>
            </div>
            

            <div class="form-group">
                <label class="control-label col-md-2" for="example-datepicker3">Data de Publicação</label>
                <div class="col-md-2">
                    <input type="text" id="dataPubli" name="dataPubli" class="form-control input-datepicker-close text-left" data-date-format="dd/mm/yy" placeholder="dd/mm/yy" value="<?echo  $_SESSION['conteudo_data'] ;?>">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-select">Tipo de Energia</label>
                <div class="col-md-2">
                    <select id="example-select" name="energia" class="form-control" size="1">
                        <option value="1" <?php if($_SESSION['conteudo_fonte'] == 1){echo "selected";};?>>Solar</option> 
                        <option value="2" <?php if($_SESSION['conteudo_fonte'] == 2){echo "selected";};?>>Hídrica</option>
                        <option value="3" <?php if($_SESSION['conteudo_fonte'] == 3){echo "selected";};?>>Eólica</option>
                        <option value="4" <?php if($_SESSION['conteudo_fonte'] == 4){echo "selected";};?>>Biomassa</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-2 control-label" for="example-text-input">Link</label>
                <div class="col-sm-7">
                    <input type="text" id="link" name="link" class="form-control" placeholder="" value="<?echo  $_SESSION['conteudo_link'] ;?>">
                    
                </div>
            </div>

            <!-- CKEditor, you just need to include the plugin (see at the bottom of this page) and add the class 'ckeditor' to your textarea -->
            <!-- More info can be found at http://ckeditor.com -->
            <div class="form-group">
                <label class="col-md-2 control-label" for="textarea-ckeditor">Conteúdo</label>
                <div class="col-md-10">
                    <textarea id="textarea-ckeditor" name="conteudo" class="ckeditor" > <?echo  $_SESSION['conteudo_conteudo'] ;?></textarea>
                    
                </div>
            </div>

            

            <div class="form-group text-right">
            
                <tr class="text-right">
                   
                    <td><button style="display: <?echo $visivelAlterar?>" type="submit" class="btn btn-warning">Alterar</button></td>
                </tr>
            </div>
            
            <div class="form-group text-right">
                <tr class="text-right">
                    <td><button style="display: <?echo $visivelSalvar?>" type="submit" class="btn btn-success">Salvar</button></td>
                    
                </tr>

            </div>
            

        </form>       
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>
<!-- ckeditor.js, load it only in the page you would like to use CKEditor -->
<script src="js/ckeditor/ckeditor.js"></script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>