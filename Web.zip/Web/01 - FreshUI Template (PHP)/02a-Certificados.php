<?php session_start(); include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<?php include '../connect_retaguarda/f21_buscaCertificado.php';?>

<div style="display:none;">

    <?php

    

    if($_GET['func']=="2"){

        pesquisa($_GET['id']);
        
        $visivelSalvar = "none";
        $visivelAlterar = "flex";

    }else{

        $_SESSION['certificado_cod'] = "";
        $_SESSION['certificado_nome'] = "";
        $_SESSION['certificado_empreendimento'] = "";
        $_SESSION['certificado_certificado'] = "";
        $_SESSION['certificado_fonte'] = "";
        $_SESSION['certificado_ano'] = "";

        
        

        $visivelSalvar = "flex";
        $visivelAlterar = "none";

    };



    ?>

</div>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Forms General Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
               Certificados - Cadastro<br><small> Cadastro de Certificados.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-pencil-square-o"></i></li>
        <li>Certificados</li>
        <li><a href="">Cadastro</a></li>
    </ul>
    <!-- END Forms General Header -->

    <!-- Basic Form Elements Block -->
    <div class="block">
        <!-- Basic Form Elements Title -->
        <div class="block-title">
            <h2>Certificado</h2>
        </div>
        <!-- END Form Elements Title -->

        <!-- Basic Form Elements Content -->
        <form action="<?echo '../connect_retaguarda/f19_salvaCertificado.php?id='. $_SESSION["00_cod"];?>" method="post" enctype="multipart/form-data" class="form-horizontal">
            <h4 class="sub-header">Cadastro</h4> 
            <div class="form-group">
                <label class="col-md-2 control-label text-left">Cadastrado por:</label>
                <div class="col-md-6">
                <p class="form-control-static text-left"><?php echo $_SESSION["00_cod"]; echo " - "; echo $_SESSION['00_nome'];?> </p> <!--Adicionar nome de usuário-->
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-2 control-label" for="example-text-input">Empreendimento Gerador</label>
                <div class="col-sm-7">
                    <input type="text" id="example-text-input" name="empreendimento" class="form-control" placeholder="" value="<?echo  $_SESSION['certificado_empreendimento'] ;?>" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                    
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="val_number">Certificado</label>
                <div class="col-sm-7">
                    <div class="input-group col-sm-7">
                        <input type="text" id="val_number" name="certificado" class="form-control" value="<?echo  $_SESSION['certificado_certificado'] ;?>" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                        
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-2 control-label" for="example-select">Tipo de Energia</label>
                <div class="col-md-2">
                    <select id="example-select" name="energia" class="form-control" size="1" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                        <option value="1" <?php if($_SESSION['certificado_fonte'] == 1){echo "selected";};?>>Solar</option> 
                        <option value="2" <?php if($_SESSION['certificado_fonte'] == 2){echo "selected";};?>>Hídrica</option>
                        <option value="3" <?php if($_SESSION['certificado_fonte'] == 3){echo "selected";};?>>Eólica</option>
                        <option value="4" <?php if($_SESSION['certificado_fonte'] == 4){echo "selected";};?>>Biomassa</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-2 control-label" for="val_number">Ano</label>
                <div class="col-md-5">
                    <div class="input-group">
                        <input type="text" id="val_number" name="ano" class="form-control" value="<?echo  $_SESSION['certificado_ano'] ;?>" <?php if ($_GET['func'] == "2"){echo 'disabled';};?>>
                        
                    </div>
                </div>
            </div>

            
        <div class="form-group text-right">
            <tr class="text-right">
                <td><button style="display: <?echo $visivelSalvar?>" type="submit" class="btn btn-success">Salvar</button></td>
                
            </tr>

        </div>
            

        </form>       
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>

<script>
    $(function(){
        /* Randomize progress bars width */
        var random = 0;

        $('.toggle-bars').click(function(){
           $('.progress-bar', '.bars-container').each(function(){
               random = getRandomInt(10, 100) + '%';
               $(this).css('width', random).html(random);
           });

           $('.progress-bar', '.bars-stacked-container').each(function(){
               random = getRandomInt(10, 25) + '%';
               $(this).css('width', random).html(random);
           });
        });

        // Get random number function from a given range
        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
    });
</script>


<?php include 'inc/bottom.php'; // Close body and html tags ?>