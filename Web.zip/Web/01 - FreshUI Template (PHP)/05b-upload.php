<?php include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>

<!-- Page content -->
<div id="page-content" class="block">
    <!-- Forms General Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
               Modelo de Aparelho - Cadastro<br><small> Cadastro de Modelo de Aparelho.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-pencil-square-o"></i></li>
        <li>Aparelho</li>
        <li><a href="">Upload</a></li>
    </ul>
    <!-- END Forms General Header -->

    <!-- Basic Form Elements Block -->
    <div class="block">
        <!-- Basic Form Elements Title -->
        <div class="block-title">
            <h2>Aparelho - Upload Planilha</h2>
        </div>
        <!-- END Form Elements Title -->

        <!-- Basic Form Elements Content -->
        <form action="page_forms_general.php" method="post" enctype="multipart/form-data" class="form-horizontal" onsubmit="return false;">
            <div class="form-group">
                <label class="col-md-2 control-label" for="example-file-input">File input</label>
                    <div class="col-md-5">
                        <input type="file" id="example-file-input" name="example-file-input">
                    </div>
            </div>
                

        </form>       
</div>

<?php include 'inc/footer.php'; // Footer and scripts ?>


<?php include 'inc/bottom.php'; // Close body and html tags ?>