

<?php session_start(); include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<div style="display: none;">
<?php include '../connect_retaguarda/f14_buscaCuriosidades.php';?>
</div>


<!-- Page content -->
<div id="page-content" class="block full">
    <!-- Datatables Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Curiosidades<br><small>Estas são as Curiosidades Cadastradas.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-th"></i></li>
        <li>Curiosidades</li>
        <li><a href="">Consulta</a></li>
    </ul>
    <!-- END Datatables Header -->

    <!-- Datatables Content -->
    <p>[Texto Explicativo]</p>
    
    <div class="table-responsive">
        <table id="example-datatable" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th>Título</th>
                    <th>Fonte</th>
                    <th>Link</th>
                    <th>Autor</th>
                    <th>Data de Cadastro</th>
                    <th>Acessos</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <?php
                $labels['4']['class'] = "label-success";
                $labels['4']['text'] = "Biomassa";

                $labels['3']['class'] = "label-primary";
                $labels['3']['text'] = "Eólica";

                $labels['2']['class'] = "label-info";
                $labels['2']['text'] = "Hídrica";

                $labels['1']['class'] = "label-danger";
                $labels['1']['text'] = "Solar";
                ?>
            <tbody>
               
                <?php foreach($resposta as $resposta): ?>
                <tr>
                    <td class="text-center"><?php echo $resposta['03_01_cod'];  ?></td>
                    <td>
                        <div>
                            <?php echo  addslashes((substr ( $resposta['03_01_titulo'] , 0 , 100 ) ));  ?>

                        </div>
                    </td>
                    <td><span class="label<?php echo ($labels[$resposta['06_cod']]['class']) ? " " . $labels[$resposta['06_cod']]['class'] : ""; ?>"><?php echo $resposta['06_descricao']; ?></span></td>
                    <td><?php echo $resposta['03_01_link'];  ?></td>
                    <td><?php echo $resposta['00_nome'];  ?></td>
                    <td><?php echo $resposta['03_01_data'];  ?></td>
                    <td><?php echo $resposta['03_01_acessos'];  ?></td>
                    <td class="text-center">
                        <div class="btn-group">
                        <a href="02a - curiosidades.php?func=2&id=<?php echo $resposta['03_01_cod']; ?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- END Datatables Content -->
</div>
<!-- END Page Content -->

<?php include 'inc/footer.php'; // Footer and scripts ?>

<!-- Javascript code only for this page -->
<script>
    $(function(){
        /* Initialize Bootstrap Datatables Integration */
        webApp.datatables();

        /* Initialize Datatables */
        $('#example-datatable').dataTable({
            columnDefs: [{orderable: false, targets: [6]}],
            pageLength: 15,
            lengthMenu: [[15, 30, 50, -1], [15, 30, 50, "All"]]
        });

        /* Add placeholder attribute to the search form */
        $('.dataTables_filter input').attr('placeholder', 'Search');
    });
</script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>