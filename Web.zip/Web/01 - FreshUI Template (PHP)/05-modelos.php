

<?php include 'inc/config.php'; // Configuration php file ?>
<?php include 'inc/top.php';    // Meta data and header   ?>
<div style="display: none;">
<?php include '../connect_retaguarda/f32_buscaModelo.php';?>
</div>


<!-- Page content -->
<div id="page-content" class="block full">
    <!-- Datatables Header -->
    <div class="block-header">
        <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
        <a href="" class="header-title-link">
            <h1>
                Modelos de Aparelhos<br><small>Estas são os modelos de aparelhos Cadastrados.</small>
            </h1>
        </a>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li><i class="fa fa-th"></i></li>
        <li>Aparelhos</li>
        <li><a href="">Consulta</a></li>
    </ul>
    <!-- END Datatables Header -->

    <!-- Datatables Content -->
    <p>[Texto Explicativo]</p>
    
    <div class="table-responsive">
        <table id="example-datatable" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th>Modelo</th>
                    <th>Consumo</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody>
               
                <?php foreach($resposta as $resposta): ?>
                <tr>
                    <td class="text-center"><?php echo $resposta['01_01_01_cod'];  ?></td>
                    <td><?php echo  (substr ( $resposta['01_01_descricao'] , 0 , 100 ). "[...]" )  ?></td>
                    <td><?php echo $resposta['01_01_consumo'];  ?></td>
                    <td class="text-center">
                        <div class="btn-group">
                        <a href="05a-modelos.php?func=2&id=<?php echo $resposta['01_01_01_cod']; ?>" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- END Datatables Content -->
</div>
<!-- END Page Content -->

<?php include 'inc/footer.php'; // Footer and scripts ?>

<!-- Javascript code only for this page -->
<script>
    $(function(){
        /* Initialize Bootstrap Datatables Integration */
        webApp.datatables();

        /* Initialize Datatables */
        $('#example-datatable').dataTable({
            columnDefs: [{orderable: false, targets: [3]}],
            pageLength: 15,
            lengthMenu: [[15, 30, 50, -1], [15, 30, 50, "All"]]
        });

        /* Add placeholder attribute to the search form */
        $('.dataTables_filter input').attr('placeholder', 'Search');
    });
</script>

<?php include 'inc/bottom.php'; // Close body and html tags ?>